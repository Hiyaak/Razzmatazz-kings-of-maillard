import React, { useContext, useEffect, useState } from "react";
import RightPanelLayout from "../../Layout/RightPanelLayout";
import { useLocation, useNavigate, useParams } from "react-router-dom";
import { AlarmClock, ArrowLeft, Minus, Plus } from "lucide-react";
import { useCart } from "../../Context/CartContext";
import ApiService, { ImagePath } from "../../Services/Apiservice";
import { LanguageContext } from "../../Context/LanguageContext";
import { useTranslation } from "react-i18next";
 
const DiyProducts = () => {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { language } = useContext(LanguageContext);
  const location = useLocation();
  const { cart, addToCart, updateQuantity } = useCart();
 
  const [subProductCategories, setSubProductCategories] = useState([]);
  const { productId } = useParams();
 
  useEffect(() => {
    if (productId) {
      getSubProductCategories(productId);
    }
  }, [productId, language]);
 
  const getSubProductCategories = async (productId) => {
    try {
      const payload = {
        product_id: productId,
        brandName: "Kings of Maillard",
      };
      const { data } = await ApiService.post("getAllSubproducts1", payload);
      console.log("Subproducts Response:", data);
      if (data.status) setSubProductCategories(data.subproducts);
    } catch (error) {
      console.log("Error fetching subproducts:", error);
    }
  };
 
  const getCartItemId = (productId) => {
    const cartItem = cart.find(
      (item) =>
        item.cartItemId === `diycombo-${productId}` ||
        item.cartItemId === `product-${productId}`,
    );
    return cartItem?.cartItemId || `diycombo-${productId}`;
  };

  const getProductQuantity = (productId) => {
    const cartItem = cart.find(
      (item) =>
        item.cartItemId === `diycombo-${productId}` ||
        item.cartItemId === `product-${productId}`,
    );
    return cartItem ? cartItem.quantity : 0;
  };
 
  const handleNavigate = (item) => {
    navigate(`/diyproductdetails/${item._id}`, {
      state: { product: item },
    });
  };
 
  return (
    <div className="flex flex-col md:flex-row min-h-screen">
      {/* Left Sidebar */}
      <div className="w-full md:w-[42%] h-screen border-r border-gray-200 flex flex-col">
        {/* Header */}
        <div className="p-2 border-b border-gray-200 flex-shrink-0">
          <div className="flex items-center justify-between mb-1">
            <button
              onClick={() => navigate(-1)}
              className="p-2 hover:bg-gray-200 rounded-full transition-colors"
            >
              <ArrowLeft className="w-5 h-5 text-gray-600" />
            </button>
 
            <h1 className="text-2xl font-semibold text-gray-900 text-center flex-1">
              {subProductCategories[0]?.productName?.toUpperCase()}
            </h1>
 
            <div className="w-9" />
          </div>
        </div>
        {/* Subproducts - Scrollable */}
        <div className="flex-1 overflow-y-auto px-4 pb-4 [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
          <div className="grid grid-cols-2 gap-4 cursor-pointer mt-8 pb-4">
            {subProductCategories.map((item) => {
              const quantity = getProductQuantity(item._id);
              const availableQuantity = item.quantity ?? 0;
              const maxReached = quantity >= availableQuantity;
              return (
                <div
                  key={item._id}
                  className="relative rounded-md overflow-hidden p-4 flex flex-col h-full" // Added h-full here
                >
                  {/* Image */}
                  <div className="w-full h-56 mb-2 overflow-hidden rounded-sm relative">
                    <img
                      src={`${ImagePath}${item.image}`}
                      alt={item.name}
                      className="w-full h-full object-cover"
                      onClick={() => handleNavigate(item)}
                    />
 
                    {/* Light gray strip at the bottom of image for timeToPrepare */}
                    {item.timeToPrepare && (
                      <div className="absolute bottom-0 w-full bg-[#F4ECD9]/80 p-1 flex justify-center items-center gap-1">
                        <AlarmClock className="w-4 h-4 text-[#FA0303]" />
                        <span className="text-[#FA0303] text-sm font-medium">
                          {item.timeToPrepare}
                        </span>
                      </div>
                    )}
                  </div>
 
                  {/* Name */}
                  <h2 className="text-lg font-semibold mb-3">{item.name}</h2>
 
                  {/* Description - Added flex-1 here */}
                  <p className="text-gray-600 text-sm mb-2 line-clamp-2 flex-1">
                    {item.description}
                  </p>
 
                  {/* Price moved here (just above Add button) */}
                  <div className="text-[#FA0303] font-bold text-right mb-3">
                    {item.price} {t("ShoopingCart.KD")}
                  </div>
 
                  {/* <button
                    onClick={() => handleNavigate(item)}
                    className='border border-[#FA0303] text-[#FA0303] px-4 rounded hover:bg-red-50 transition-colors font-medium w-full'
                  >
                    + {t('ShoopingCart.Add')}
                  </button> */}
                  {item.quantity > 0 ? (
                    quantity === 0 ? (
                      <button
                        onClick={() => handleNavigate(item)}
                        className="border border-[#FA0303] text-[#FA0303] px-4 rounded hover:bg-red-50 transition-colors font-medium w-full"
                      >
                        + {t("ShoopingCart.Add")}
                      </button>
                    ) : (
                      <div className="flex items-center justify-between px-2 py-1">
                        <button
                          onClick={() =>
                            updateQuantity(
                              getCartItemId(item._id),
                              quantity - 1,
                              availableQuantity
                            )
                          }
                          className="w-6 h-6 flex items-center justify-center border border-[#FA0303] rounded-full text-[#FA0303]"
                        >
                          <Minus className="w-3 h-3" />
                        </button>

                        <span className="text-[#FA0303] font-medium">
                          {quantity}
                        </span>

                        <button
                          onClick={() =>
                            updateQuantity(
                              getCartItemId(item._id),
                              quantity + 1,
                              availableQuantity
                            )
                          }
                          disabled={maxReached}
                          className={`w-6 h-6 flex items-center justify-center border border-[#FA0303] rounded-full text-[#FA0303] ${
                            maxReached
                              ? "opacity-50 cursor-not-allowed"
                              : ""
                          }`}
                        >
                          <Plus className="w-3 h-3" />
                        </button>
                      </div>
                    )
                  ) : (
                    <button
                      disabled
                      className="border border-[#FA0303] text-[#FA0303] px-4 rounded hover:bg-red-50 transition-colors font-medium w-full"
                    >
                      {t("Item Out of stock")}
                    </button>
                  )}
                </div>
              );
            })}
          </div>
        </div>
      </div>
      {/* Right Panel - Fixed, No Scroll */}
      <RightPanelLayout />
    </div>
  );
};
 
export default DiyProducts;
 
 