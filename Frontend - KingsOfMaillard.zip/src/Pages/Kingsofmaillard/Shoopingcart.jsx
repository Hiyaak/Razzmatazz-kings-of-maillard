import React, { useEffect, useState } from 'react'
import {
  ArrowLeft,
  Plus,
  Minus,
  MessageSquareText,
  PenLine
} from 'lucide-react'
import { useNavigate } from 'react-router-dom'
import { useCart } from '../../Context/CartContext'
import ApiService, { ImagePath } from '../../Services/Apiservice'
import RightPanelLayout from '../../Layout/RightPanelLayout'
import { RiShoppingBasketLine } from 'react-icons/ri'
import { useTranslation } from 'react-i18next'

const ShoppingCartPage = () => {
  const navigate = useNavigate()
  const { cart, updateQuantity, removeFromCart, getCartItemsCount } = useCart()
  const [specialRemark, setSpecialRemark] = useState('')
  
  const [isSpecialRemarksEnabled, setIsSpecialRemarksEnabled] = useState(false)
  const { t } = useTranslation()

  useEffect(() => {
    console.log('Cart Data:', cart)
  }, [cart])
  const brandId = localStorage.getItem('brandId')

  const { selectedMethod, selectedGovernate, selectedArea } = JSON.parse(
    localStorage.getItem(`selectedLocation_${brandId}`) || '{}'
  )

  const handleGotocheckout = async () => {
    const storedBrandId = localStorage.getItem('brandId')

    if (!storedBrandId) {
      toast.error('No brand selected')
      return
    }

    const guestUserId = sessionStorage.getItem(`guestUserId_${storedBrandId}`)
    const registredUserId = localStorage.getItem(
      `registredUserId_${storedBrandId}`
    )

    if (!guestUserId && !registredUserId) {
      navigate('/login')
      return
    }

    const userId = registredUserId || guestUserId

    try {
      const { data } = await ApiService.get(`getAddressesByUser/${userId}`)

      if (data.status && data.addresses.length > 0) {
        navigate('/placeorder', {
          state: {
            specialRemark: specialRemark
          }
        })
      } else {
        navigate('/adress')
      }
    } catch (error) {
      console.error('Error fetching addresses:', error)
      toast.error('Something went wrong while fetching your addresses.')
    }
  }

  useEffect(() => {
    const fetchRemarkStatus = async () => {
      try {
        const brandId = localStorage.getItem('brandId')

        const { data } = await ApiService.get(`getRemarkByBrand/${brandId}`)

        if (data.status) {
          setIsSpecialRemarksEnabled(data.isSpecialRemarksEnabled)
        }
      } catch (error) {
        console.error('Remark API error:', error)
      }
    }

    fetchRemarkStatus()
  }, [])

  const formatCartDate = date => {
    const d = new Date(date)
    return d.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: '2-digit'
    })
  }

  const getEndTime = time24 => {
    const [hour, minute] = time24.split(':')
    const date = new Date()
    date.setHours(hour)
    date.setMinutes(minute)
    date.setHours(date.getHours() + 1)

    return date.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: false
    })
  }

  const uniqueCart = React.useMemo(() => {
  const map = new Map();

  cart.forEach((item) => {
    const key =
      item.type === "catering"
        ? `catering-${item.packageId}`
        : item.cartItemId;

    if (!map.has(key)) {
      map.set(key, item);
    }
  });

  return Array.from(map.values());
}, [cart]);

  return (
    <div className='flex flex-col md:flex-row min-h-screen'>
      {/* Left Sidebar (40% on desktop, full on mobile) */}
      <div className='w-full md:w-[42%] h-screen border-r border-gray-200 flex flex-col'>
        {/* Header */}
        <div className='p-2 border-b border-gray-200 flex-shrink-0'>
          <div className='flex items-center justify-between mb-1'>
            <button
              onClick={() => navigate(-1)}
              className='p-2 hover:bg-gray-200 rounded-full transition-colors'
            >
              <ArrowLeft className='w-5 h-5 text-gray-600' />
            </button>

            <h1 className='text-2xl font-semibold text-gray-900 text-center flex-1'>
              {/* Shopping Cart */}
              {t('ShoopingCart.ShoppingCart')}
            </h1>

            <div className='w-9' />
          </div>
        </div>

        {/* Scrollable Content */}
        <div className='flex-1 overflow-y-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]'>
          {isSpecialRemarksEnabled && (
            <div>
              <div className='bg-gray-100 p-4'>
                <h2 className='text-base font-semibold text-gray-800'>
                  {t('ShoopingCart.Special Remarks')}
                </h2>
              </div>

              <div className='bg-white p-5 border-gray-300'>
                <div className='flex items-center gap-3'>
                  <MessageSquareText className='w-5 h-5 text-gray-500' />

                  <input
                    type='text'
                    value={specialRemark}
                    onChange={e => setSpecialRemark(e.target.value)}
                    placeholder={t('ShoopingCart.placeholder')}
                    className='w-full bg-transparent border-b border-gray-300 focus:border-red-500 outline-none focus:ring-0 text-gray-700 placeholder-gray-500 text-sm pb-1'
                  />
                </div>
              </div>
            </div>
          )}

          {/* Items Section */}
          <div>
            <div className='bg-gray-100 p-4 border-b border-gray-200'>
              <h2 className='text-base font-semibold text-gray-800'>
                {t('ShoopingCart.Item')}
              </h2>
            </div>

            {cart.length === 0 ? (
              <div className='flex px-4 gap-5 py-10 bg-white'>
                {/* Left: Shopping Icon */}
                <RiShoppingBasketLine className='w-16 h-16 text-red-300 relative top-3' />

                {/* Right: Text + Button */}
                <div>
                  <p className='text-gray-800 font-semibold mb-1'>
                    {/* Your cart is empty. */}
                    {t('ShoopingCart.cartEmpty')}
                  </p>
                  <p className='text-gray-500 text-sm mb-4'>
                    {/* Add some items to your cart. */}
                    {t('ShoopingCart.addToCart')}
                  </p>
                  <button
                    onClick={() => navigate('/')}
                    className='px-5 py-2 border border-[#FA0303] text-[#FA0303] font-medium rounded-md hover:bg-red-50 transition-colors'
                  >
                    {/* Start Shopping */}
                    {t('ShoopingCart.startShopping')}
                  </button>
                </div>
              </div>
            ) : (
              <div className='space-y-4 mt-1 px-4 border-b border-gray-200'>
                {uniqueCart.map(item => (
                  <div
                    key={item.cartItemId}
                    className='border-b border-gray-200 pb-4 last:border-b-0'
                  >
                    {/* Edit Button */}
                    {item.type === 'catering' && (
                      <button
                        onClick={() =>
                          navigate(`/package/${item.packageId}`, {
                            state: {
                              cartItemId: item.cartItemId,
                              isEdit: true
                            }
                          })
                        }
                        className='text-[#FA0303] text-sm font-medium mb-2'
                      >
                        edit
                      </button>
                    )}

                    <div className='flex items-center justify-between'>
                      {/* Image */}
                      <img
                        src={
                          item.image?.startsWith('http')
                            ? item.image
                            : `${ImagePath}${item.image}`
                        }
                        alt={item.name}
                        className='w-16 h-16 object-cover rounded-md'
                      />

                      {/* Name */}
                      <div className='flex-1 px-4 mb-6'>
                        <h2 className='text-lg font-semibold'>{item.name}</h2>

                        {/* DATE & TIME */}
                        {item.date && item.time && (
                          <p className='text-sm text-gray-500 mt-1'>
                            {formatCartDate(item.date)} - {item.time} 
                          </p>
                        )}

                        {/* SELECTED MENU ITEMS */}
                        <div className='mt-2 space-y-1 text-sm text-gray-700'>
                          {item.selections &&
                            Object.entries(item.selections).map(
                              ([categoryId, categoryData]) => (
                                <div key={categoryId}>
                                  {/* Category Name */}
                                  <p className='font-medium text-gray-800'>
                                    {categoryData.name}
                                  </p>

                                  {/* Items */}
                                  {categoryData.items.map(
                                    (selectedItem, index) => (
                                      <div key={selectedItem.id || index}>
                                        {selectedItem.name}

                                        {/* ✅ YES / NO DISPLAY */}
                                        {selectedItem.isYesNoType && (
                                          <span className='ml-2 text-gray-500'>
                                            -{' '}
                                            {selectedItem.selectedValue
                                              ? 'Yes'
                                              : 'No'}
                                          </span>
                                        )}

                                        {/* Normal items */}
                                        {!selectedItem.isYesNoType && (
                                          <span className='text-gray-400'>
                                            {' '}
                                            x1
                                          </span>
                                        )}
                                      </div>
                                    )
                                  )}
                                </div>
                              )
                            )}

                          {/* ADDITIONAL SERVICES */}
                          {item.additionalServices &&
                            Object.entries(item.additionalServices).map(
                              ([serviceId, serviceData]) => (
                                <div key={serviceId}>
                                  {serviceData.name}{' '}
                                  <span className='text-gray-400'>
                                    x{serviceData.quantity}
                                  </span>
                                </div>
                              )
                            )}
                        </div>

                        {item.type === 'combo' && (
                          <p className='text-xs text-gray-500'>Combo item</p>
                        )}
                      </div>

                      {/* Price & Quantity */}
                      <div className='flex flex-col items-end'>
                        <span className='text-[#FA0303] font-medium mb-5'>
                          {(item.price * item.quantity).toFixed(3)}{' '}
                          {t('ShoopingCart.KD')}
                        </span>

                        <div className='flex items-center gap-2'>
                          <button
                            onClick={() =>
                              updateQuantity(item.cartItemId, item.quantity - 1)
                            }
                            className={`w-4 h-4 flex items-center justify-center border-2 rounded-full hover:bg-gray-100 transition-colors ${
                              item.quantity > 1
                                ? 'border-[#FA0303] text-[#FA0303]'
                                : 'border-gray-300 text-gray-300'
                            }`}
                          >
                            <Minus className='w-3 h-3' />
                          </button>

                          <span className='px-4 py-0.5 text-center font-medium text-[#FA0303] text-sm border border-gray-300 rounded'>
                            {item.quantity}
                          </span>

                          <button
                            onClick={() =>
                              item.type !== 'catering' &&
                              updateQuantity(item.cartItemId, item.quantity + 1)
                            }
                            disabled={
                              item.type === 'catering' ||
                              (item.maxQuantity > 0 &&
                                item.quantity >= item.maxQuantity)
                            }
                            className={`w-4 h-4 flex items-center justify-center border-2 rounded-full transition-colors
    ${
      item.type === 'catering' ||
      (item.maxQuantity > 0 && item.quantity >= item.maxQuantity)
        ? 'border-gray-300 text-gray-300 cursor-not-allowed'
        : 'border-[#FA0303] text-[#FA0303] hover:bg-red-50'
    }`}
                          >
                            <Plus className='w-3 h-3' />
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Remove */}
                    <button
                      onClick={() => removeFromCart(item.cartItemId)}
                      className='text-[#f34f4f] text-sm font-medium'
                    >
                      {t('ShoopingCart.remove')}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Order Summary - Fixed at Bottom (No Scroll) */}
        {cart.length > 0 &&
          (!(selectedMethod && (selectedArea || selectedGovernate)) ? (
            <div className='p-3 border-t border-gray-200 bg-white flex-shrink-0'>
              <button
                onClick={() => navigate('/pickupdeviler')}
                className='w-full bg-[#FA0303] hover:bg-[#AF0202] text-white font-bold py-3 rounded-lg transition-colors'
              >
                {t('brand.Selectlocation')}
              </button>
            </div>
          ) : (
            <div
              className='p-3  bg-white flex-shrink-0'
              onClick={handleGotocheckout}
            >
              <button className='w-full bg-[#FA0303] hover:bg-[#AF0202] text-white font-bold py-3 rounded-lg transition-colors flex items-center justify-between px-6'>
                {/* Left - Items Count */}
                <div className='flex items-center'>
                  <span className='bg-white/20 rounded-sm w-6 h-6 flex items-center justify-center text-sm'>
                    {getCartItemsCount()}
                  </span>
                </div>

                {/* Center - Checkout Text */}
                <span>{t('ShoopingCart.checkout')}</span>

                {/* Right - Total Price */}
                <span>
                  {cart
                    .reduce(
                      (total, item) => total + item.price * item.quantity,
                      0
                    )
                    .toFixed(3)}{' '}
                  {t('ShoopingCart.KD')}
                </span>
              </button>
            </div>
          ))}
      </div>

      {/* Right Panel - Fixed, No Scroll */}
      <RightPanelLayout />
    </div>
  )
}

export default ShoppingCartPage
