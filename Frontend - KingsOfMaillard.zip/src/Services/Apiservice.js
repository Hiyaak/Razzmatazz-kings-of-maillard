import axios from 'axios'

export const ImagePath =
 "https://razzmatazz-assets.s3.eu-north-1.amazonaws.com/attachments/"

const API_URL = import.meta.env.VITE_API_URL

const axiosInstance = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json'
  }
})

axiosInstance.interceptors.request.use(config => {
  const language = localStorage.getItem('lang') || 'en'

  if (!config.headers) {
    config.headers = {}
  }

  config.headers['Accept-Language'] = language

  return config
})

const ApiService = {
  get: (endpoint, params, token) =>
    axiosInstance.get(endpoint, {
      params,
      headers: token ? { Authorization: `Bearer ${token}` } : {}
    }),
  post: (endpoint, data, token) =>
    axiosInstance.post(endpoint, data, {
      headers: token ? { Authorization: `Bearer ${token}` } : {}
    }),
  put: (endpoint, data, token) =>
    axiosInstance.put(endpoint, data, {
      headers: token ? { Authorization: `Bearer ${token}` } : {}
    }),
  delete: (endpoint, data = null, token) =>
    axiosInstance.delete(endpoint, {
      headers: token ? { Authorization: `Bearer ${token}` } : {},
      data
    })
}
export default ApiService
