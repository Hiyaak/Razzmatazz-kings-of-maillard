 
import { initializeApp } from "firebase/app";
 
const firebaseConfig = {
  apiKey: "AIzaSyB-HLjIoO4bqia8ndfXvMXkDMsd53Gx9Uk",
  authDomain: "pushnotificationrazzmatazz.firebaseapp.com",
  projectId: "pushnotificationrazzmatazz",
  storageBucket: "pushnotificationrazzmatazz.firebasestorage.app",
  messagingSenderId: "622773877166",
  appId: "1:622773877166:web:d3ef5154b6e6ad6c9ef03f",
  measurementId: "G-GTZYKTMC29",
};
 
const app = initializeApp(firebaseConfig);
 
// Temporarily disable FCM
export const messaging = null;
 
export const requestFcmToken = async () => {
  console.log("FCM disabled");
  return null;
};
 
export const onMessageListener = () => {
  console.log("FCM disabled");
  return Promise.resolve(null);
};
 
export default app;